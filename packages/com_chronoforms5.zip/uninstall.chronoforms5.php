<?php
/* @copyright:ChronoEngine.com @license:GPLv2 */defined('_JEXEC') or die('Restricted access');
function com_uninstall() {
	echo "Thank you for using ChronoContact. The component has been uninstalled, If you have any questions or comments, please kindly contact us at this email address: webmaster@chronoengine.com";
}
?>